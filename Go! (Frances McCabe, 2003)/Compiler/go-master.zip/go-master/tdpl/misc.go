tdpl.misc{
  do <~ { do:[]* }.
  do:[]@=do.
  do..{
    do()->{}
  }.

  ev[T] <~ { ev:[]=>T. }.
}