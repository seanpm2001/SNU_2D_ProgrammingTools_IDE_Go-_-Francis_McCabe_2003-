go.do{
  do <~ { do:[]* }.
  do:[]@=do.
  do..{
    do()->{}
  }.

  ev[T] <~ { ev:[]=>T. }.
}