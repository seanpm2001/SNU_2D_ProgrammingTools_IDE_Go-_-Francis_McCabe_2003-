monad{
  -- A simple version of the Haskell-style monad

  monad[t] <~ {
	do:[]=>