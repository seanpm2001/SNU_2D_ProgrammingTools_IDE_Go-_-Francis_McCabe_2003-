mysql.parse{
  import go.stdparse.
  import mysql.sqltypes.


}