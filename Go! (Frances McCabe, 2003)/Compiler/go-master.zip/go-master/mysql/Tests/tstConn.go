tstConn{
  import go.io.
  import mysql.misc.
}