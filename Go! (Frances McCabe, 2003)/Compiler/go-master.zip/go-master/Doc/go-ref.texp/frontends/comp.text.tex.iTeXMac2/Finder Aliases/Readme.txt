This directory contains finder aliases to files the project is aware of.
iTeXMac2