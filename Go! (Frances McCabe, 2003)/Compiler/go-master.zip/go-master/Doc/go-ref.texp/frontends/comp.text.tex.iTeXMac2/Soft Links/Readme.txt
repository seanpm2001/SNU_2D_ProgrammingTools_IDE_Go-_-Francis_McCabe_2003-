This directory contains soft links to files the project is aware of.
iTeXMac2