bintree{
  tree[T] ::= leaf(T) | node(tree[T],tree[T]).
}
  