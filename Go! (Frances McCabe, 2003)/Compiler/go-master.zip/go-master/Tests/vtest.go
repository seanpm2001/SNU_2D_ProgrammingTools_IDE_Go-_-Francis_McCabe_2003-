vtest{
  import go.io.

  main(_) ->
      stdout.outLine(_.show())
}