s{

  s <~ { st:[]*. }.

  ss:[]@=s.
  ss..{
    st() ->
        _ = show().
  }
}