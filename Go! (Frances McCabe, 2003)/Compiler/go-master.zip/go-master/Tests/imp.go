imp{
  import foo.
  import bar.
  import go.io.

  main(_) ->
      foo#test();
      foo#tt();
      go.io#stdout.outLine("imp").
}
