hello{
  import go.io.

  main(_)->
      stdout.outLine("hello, world!").
}