n{

  c[t] <~ { equal:[t]{}}.

  cc:c[t]..{
    equal(this)
  }.
}