#ifndef _Q_SORT_H_
#define _Q_SORT_H_

retCode m_sort(processpo p,objPo *args);
retCode m_setof(processpo p,objPo *args);

int cmpcell(register objPo c1,register objPo c2);

#endif
