/*
 * String handling utilities
 */

#ifndef _STR_FILE_H_
#define _STR_FILE_H_

#include "unicode.h"

retCode closeOutString(ioPo f,heapPo P,ptrPo tgt);

#endif
