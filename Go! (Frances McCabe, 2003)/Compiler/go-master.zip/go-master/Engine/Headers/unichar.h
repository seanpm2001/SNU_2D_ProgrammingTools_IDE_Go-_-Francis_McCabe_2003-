#ifndef _UNICHAR_H_
#define _UNICHAR_H_

/*
 * Our definition of a unicode character 
 */
#include "config.h"

typedef WORD32 uniChar;

#endif

