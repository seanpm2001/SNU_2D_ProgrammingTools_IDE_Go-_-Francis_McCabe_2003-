/*
 * Private header file for the heap management of April
 */

#ifndef _GC_P_H_
#define _GC_P_H_

/* Used for recording old->new pointers */

#endif
