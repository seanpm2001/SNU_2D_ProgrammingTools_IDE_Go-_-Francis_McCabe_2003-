s{
  import t.

  check:[logical]{}.
  check(t#true).
  check(false).
  check(t#T).
  check(_) :- _ = false.show().

     
}
