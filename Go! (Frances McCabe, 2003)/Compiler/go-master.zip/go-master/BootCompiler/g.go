g{
  shape <~ {
	paint:[rectangle]*.
      }.

  rectangle <~ shape.
}
