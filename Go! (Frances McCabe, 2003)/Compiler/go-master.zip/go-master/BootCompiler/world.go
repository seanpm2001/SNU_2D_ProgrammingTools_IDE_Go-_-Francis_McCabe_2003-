world{
  import app.

  main:()*.
  main() -> 
      { __logmsg("hello"<>" world")}.
}